import math
import numpy as np
import matplotlib.pyplot as plt
import copy

from Configuration import Configuration
from Setup import Setup
from Testing import Testing

#Makes graphs utilizing the information from the Testing
class Graphing:
    def __init__(self, pressureInlet,pressureOutlet,airflowInlet,airflowOutlet,pressureIN, pressureOUT, airflowIN, airflowOUT, pressureEntrance,pressureExit,airflowEntrance,airflowExit):
        self.pressureIN = pressureIN
        self.pressureOUT = pressureOUT
        self.airflowIN = airflowIN
        self.airflowOUT = airflowOUT
        timecount = []
        
        for i in range(60):
            for d in range(40):
                timecount.append(copy.copy(i))

            

        graphList = [[pressureIN,pressureOUT, 'PvP'],[pressureIN,airflowOUT,'PvA'],[airflowIN,pressureOUT,'AvP'],[airflowIN,airflowOUT,'AvA'], 
        [timecount, pressureEntrance, 'TvPEn'], [timecount, airflowEntrance, 'TvAEn'], [timecount, pressureExit, 'TvPEx'], [timecount, airflowExit, 'TvAEx'],
        [pressureOutlet,pressureInlet,'OPvIP'],[airflowOutlet,pressureInlet,'OAvIP'],[pressureOutlet,airflowInlet,'POvAI'], [airflowOutlet, airflowInlet, "PAvIA"]]
        #Makes the Graphs

        for graph in graphList:
            plt.plot(graph[0],graph[1], 'o', label='datapoints')

            x = np.array(graph[0])
            y = np.array(graph[1])
            order = np.argsort(x)
            x = x[order]
            y = y[order]
            a,b,c,d = np.polyfit(x,y,3)
            plt.plot(x, a*x*x*x + b*x*x + c*x + d)
            plt.plot([],[],label = 'f(x) = ' + str(a) + 'x^3 ' + '+ ' +  str(b) + 'x^2 ' + '+ ' + str(c) + 'x ' + '+ ' +  str(d))
            plt.legend()
            #Outlet Test
            if graph[2] == ('OPvIP'):
                plt.ylabel('Pressure Inlet (kPa)')
                plt.xlabel('Pressure Outlet (kPa)')
                plt.title('Pressure Outlet vs Pressure Inlet')
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()
            if graph[2] == ('OAvIP'):
                plt.ylabel('Pressure Inlet (kPa)')
                plt.xlabel('Airflow Outlet (m/s)')
                plt.title('Airflow Outlet vs Pressure Inlet')
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()
            if graph[2] == ('OPvIA'):
                plt.ylabel('Airflow Inlet (m/s)')
                plt.xlabel('Pressure Outlet (kPa)')
                plt.title('Pressure Outlet vs Airflow Inlet')
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()
            if graph[2] == ('OAvIA'):
                plt.ylabel('Airflow Inlet (m/s)')
                plt.xlabel('Airflow Outlet (m/s)')
                plt.title('Airflow Outlet vs Airflow Inlet')
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()
            
            #Inlet Test
            if graph[2] == ('PvP'):
                plt.ylabel('Pressure Outlet (kPa)')
                plt.xlabel('Pressure Inlet (kPa)')
                plt.title('Pressure Inlet vs Pressure Outlet')
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()
            if graph[2] == ('AvA'):
                plt.ylabel('Airflow Outlet (m/s)')
                plt.xlabel('Airflow Inlet (m/s)')
                plt.title("Airflow Inlet vs Airflow Outlet")
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()
            if graph[2] == ('PvA'):
                plt.xlabel('Pressure Inlet (kPa)')
                plt.ylabel('Airflow Outlet (m/s)')
                plt.title('Pressure Inlet vs Airflow Outlet')
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()
            if graph[2] == ('AvP'):
                plt.xlabel('Airflow Inlet (m/s)')
                plt.ylabel('Presure Outlet (kPa)')
                plt.title('Airflow Inlet vs Pressure Outlet')
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()
            #Air Holding Test
            if graph[2] == ('TvPEn'):
                plt.xlabel('Time (s)')
                plt.ylabel('Presure Inlet (kPa)')
                plt.title('Time vs Pressure at Inlet')
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()
            if graph[2] == ('TvPEx'):
                plt.xlabel('Time (s)')
                plt.ylabel('Presure Outlet (kPa)')
                plt.title('Time vs Pressure at Outlet')
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()
            if graph[2] == ('TvAEn'):
                plt.xlabel('Time (s)')
                plt.ylabel('Airflow Inlet (m/s)')
                plt.title('Time vs Airflow at Inlet')
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()
            if graph[2] == ('TvAEx'):
                plt.xlabel('Time (s)')
                plt.ylabel('Airflow Outlet (m/s)')
                plt.title('Time vs Airflow at Outlet')
                print("SAVE MANUALLY")
                plt.show()
                plt.clf()

