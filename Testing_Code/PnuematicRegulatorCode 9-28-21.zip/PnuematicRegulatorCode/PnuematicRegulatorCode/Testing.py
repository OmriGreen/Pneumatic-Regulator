import math
import numpy as np
import nidaqmx as ni
import time as time

from Configuration import Configuration
from Setup import Setup
from Calculation import Calculation

#Tests the device in the system
class Testing:
    def __init__(self, setup, config):
        self.setup = setup
        self.config = config
        eqAI0 = setup.sensorAI0
        eqAI1 = setup.sensorAI1
        eqAI2 = setup.sensorAI2
        eqAI3 = setup.sensorAI3

        airflowIn = []
        airflowOut = []

        pressureIn = []
        pressureOut = []

        

        #Collects Pressure In and Pressure Out when the inlet is facing the pressure Source
        for pressure in config.pressureList:
            print("\n Press enter when the pressure is at " + str(pressure) + "kPa")
            check = input()

            for i in range(20):
                #AI0 and AI1 find pressureIn
                with ni.Task() as task0:
                    task0.ai_channels.add_ai_voltage_chan("Dev1/ai0")
                    v0 = float(task0.read())
                    p0 = abs(eqAI0[0]*v0+ eqAI0[1])
                    airflowIn.append(Calculation(p0 / 1000,config.fluidDensity,config.area).airFlow)
                    pressureIn.append(p0)
                with ni.Task() as task1:
                    task1.ai_channels.add_ai_voltage_chan("Dev1/ai1")
                    v1 = float(task1.read())
                    p1 = abs(eqAI1[0]*v1 + eqAI1[1])
                    airflowIn.append(Calculation(p1 / 1000,config.fluidDensity,config.area).airFlow)
                    pressureIn.append(p1)

                #AI2 and AI3 find pressureOut
                with ni.Task() as task2:
                    task2.ai_channels.add_ai_voltage_chan("Dev1/ai2")
                    v2 = float(task2.read())
                    p2 = abs(eqAI2[0]*v2 + eqAI2[1])
                    airflowOut.append(Calculation(p2 / 1000,config.fluidDensity,config.area).airFlow)
                    pressureOut.append(p2)
                with ni.Task() as task3:
                    task2.ai_channels.add_ai_voltage_chan("Dev1/ai3")
                    v3 = float(task3.read())
                    p3 = abs(eqAI3[0]*v3+  eqAI3[1])
                    airflowOut.append(Calculation(p3 / 1000,config.fluidDensity,config.area).airFlow)
                    pressureOut.append(p3)

        self.pressureIn = pressureIn
        self.pressureOut = pressureOut
        self.airflowIn = airflowIn
        self.airflowOut = airflowOut
        print("\nAIRFLOW INLET TESTING COMPLETE")

        print("\nPress enter when the Outlet is facing the Pressure Source")
        check = input()
        #Collects Pressure from the Inlet and Outlet when the pressure source is facing the outlet
        airflowOutlet = []
        airflowInlet = []

        pressureOutlet = []
        pressureInlet = []

        for pressure in config.pressureList:
            print("\n Press enter when the pressure is at " + str(pressure) + "kPa")
            check = input()

            for i in range(20):
                #AI0 and AI1 find pressureOutlet
                with ni.Task() as task0:
                    task0.ai_channels.add_ai_voltage_chan("Dev1/ai0")
                    v0 = float(task0.read())
                    p0 = abs(eqAI0[0]*v0+ eqAI0[1])
                    airflowOutlet.append(Calculation(p0 / 1000,config.fluidDensity,config.area).airFlow)
                    pressureOutlet.append(p0)
                with ni.Task() as task1:
                    task1.ai_channels.add_ai_voltage_chan("Dev1/ai1")
                    v1 = float(task1.read())
                    p1 = abs(eqAI1[0]*v1 + eqAI1[1])
                    airflowOutlet.append(Calculation(p1 / 1000,config.fluidDensity,config.area).airFlow)
                    pressureOutlet.append(p1)

                #AI2 and AI3 find pressureInlet
                with ni.Task() as task2:
                    task2.ai_channels.add_ai_voltage_chan("Dev1/ai2")
                    v2 = float(task2.read())
                    p2 = abs(eqAI2[0]*v2 + eqAI2[1])
                    airflowInlet.append(Calculation(p2 / 1000,config.fluidDensity,config.area).airFlow)
                    pressureInlet.append(p2)
                with ni.Task() as task3:
                    task2.ai_channels.add_ai_voltage_chan("Dev1/ai3")
                    v3 = float(task3.read())
                    p3 = abs(eqAI3[0]*v3+  eqAI3[1])
                    airflowInlet.append(Calculation(p3 / 1000,config.fluidDensity,config.area).airFlow)
                    pressureInlet.append(p3)
        
        self.airflowInlet = airflowInlet
        self.airflowOutlet = airflowOutlet

        self.pressureInlet = pressureInlet
        self.pressureOutlet = pressureOutlet

        print("\n Press enter when the container is pressurized and attached to the setup")
        check = input()
        #Pressure over time with a container full of air




        pressureExit = []
        airflowExit = []

        pressureEntrance = []
        airflowEntrance = []

        for d in range(60):
            for i in range(20):
                with ni.Task() as t0:
                    t0.ai_channels.add_ai_voltage_chan("Dev1/ai0")
                    v0 = float(t0.read())
                    p0 = abs(eqAI0[0]*v0 + eqAI0[1])
                    pressureEntrance.append(p0)
                    airflowEntrance.append(Calculation(p0/ 1000 ,config.fluidDensity,config.area).airFlow)
                with ni.Task() as t1:
                    t1.ai_channels.add_ai_voltage_chan("Dev1/ai1")
                    v1 = float(t1.read())
                    p1 = abs(eqAI1[0]*v1 + eqAI1[1])
                    pressureEntrance.append(p1)
                    airflowEntrance.append(Calculation(p1,config.fluidDensity,config.area).airFlow)
                with ni.Task() as t2:
                    t2.ai_channels.add_ai_voltage_chan("Dev1/ai2")
                    v2 = float(t2.read())
                    p2 = abs(eqAI2[0]*v2 + eqAI2[1])
                    pressureExit.append(p2)
                    airflowExit.append(Calculation(p2 / 1000,config.fluidDensity,config.area).airFlow)
                with ni.Task() as t3:
                    t3.ai_channels.add_ai_voltage_chan("Dev1/ai3")
                    v3 = float(t3.read())
                    p3 = abs(eqAI3[0]*v3 + eqAI3[1])
                    pressureExit.append(p3)
                    airflowExit.append(Calculation(p3 / 1000,config.fluidDensity,config.area).airFlow)
            time.sleep(1) #Sleep for 1s
        self.pressureExit = pressureExit
        self.airflowExit = airflowExit
        self.pressureEntrance = pressureEntrance
        self.airflowEntrance = airflowEntrance


        

       



