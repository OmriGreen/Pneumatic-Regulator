
import Configuration as config
import math

class Calculation:

    #Calculates Flow Velocity in m/s
    def FlowVelocity(self, dynamicPressure, fluidPressure):
        self.dynamicPressure = dynamicPressure
        self.fluidPressure = fluidPressure
        #Calculates and returns value
        return math.sqrt((2*dynamicPressure)/fluidPressure)


    #Calculates Air Flow
    def AirFlow(self, flowVelocity, area):
        self.flowVelocity = flowVelocity
        self.area = area

        #Calculates and returns Air Flow
        return flowVelocity * area


    def __init__(self, dynamicPressure, fluidPressure, area):
        flowVelocity = self.FlowVelocity(dynamicPressure, fluidPressure)
        self.flowVelocity = flowVelocity

        airFlow = self.AirFlow(flowVelocity, area)
        self.airFlow = airFlow

